-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.1.0 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para tp_final
CREATE DATABASE IF NOT EXISTS `tp_final` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tp_final`;

-- Volcando estructura para tabla tp_final.compradores
CREATE TABLE IF NOT EXISTS `compradores` (
  `id_comprador` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `email` varchar(320) COLLATE latin1_spanish_ci NOT NULL,
  `cantidad` int NOT NULL,
  `categoria` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `total_precio` float NOT NULL,
  PRIMARY KEY (`id_comprador`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla tp_final.compradores: ~5 rows (aproximadamente)
INSERT INTO `compradores` (`id_comprador`, `nombre`, `apellido`, `email`, `cantidad`, `categoria`, `total_precio`) VALUES
	(1, 'Carlos', 'Hernández', 'c.hernandez@example.com', 2, 'trainee', 200),
	(2, 'Laura', 'Soto', 'lau.soto@example.com', 1, 'junior', 200),
	(3, 'Patricia', 'Cárdenas', 'pato.cardenas@example.com', 5, 'estudiante', 170),
	(4, 'Javier', 'Ibarra', 'javi.iba@example.com', 2, 'junior', 200),
	(5, 'Juan Carlos', 'Huerta', 'juanca.h@example.com', 6, 'trainee', 600);

-- Volcando estructura para tabla tp_final.oradores
CREATE TABLE IF NOT EXISTS `oradores` (
  `id_orador` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `email` varchar(320) COLLATE latin1_spanish_ci NOT NULL,
  `tema` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `detalles_tema` varchar(250) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha_alta` timestamp NOT NULL,
  PRIMARY KEY (`id_orador`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla tp_final.oradores: ~19 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `email`, `tema`, `detalles_tema`, `fecha_alta`) VALUES
	(1, 'Miguel', 'Franco', 'migue.franco@example.com', 'Node.Js', 'Node.js es un entorno de ejecución de un solo hilo y multiplataforma basado en el motor V8 de JavaScript de Google Chrome. Es un software de código abierto para construir aplicaciones de red escalables y en tiempo real.', '2023-12-18 03:00:00'),
	(2, 'Fernanda', 'Castillo', 'fer.castillo@example.com', 'React.Js', '¿Qué es React? React.js, comúnmente llamado simplemente React, es una biblioteca de JavaScript que se utiliza para construir interfaces de usuario.', '2023-12-18 03:00:00'),
	(3, 'Pablo', 'Gómez', 'p.gomez@example.com', 'PHP', 'PHP es un lenguaje de código abierto muy popular especialmente adecuado para el desarrollo web y que puede ser incrustado en HTML. ', '2023-12-18 03:00:00'),
	(4, 'Andrea', 'Silva', 'andre.sil@example.com', 'HTML + CSS', 'El Lenguaje de Marcado de Hipertexto (HTML) es el código que se utiliza para estructurar y desplegar una página web y sus contenidos.', '2023-12-18 03:00:00'),
	(5, 'Gabriela', 'Vargas', 'gabriela.v@example.com', 'Digital market', 'El marketing digital es un conjunto de técnicas y estrategias que promueven a una marca en entornos de internet como los sitios web, buscadores y redes sociales.', '2023-12-18 03:00:00');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
